library(plyr)
my_dir <- "/Users/HP"
zip_file <- list.files(path = my_dir, pattern = "*.zip",
                       full.names = TRUE)

zip_file
ldply(.data = zip_file, .fun = unzip, exdir = my_dir)

